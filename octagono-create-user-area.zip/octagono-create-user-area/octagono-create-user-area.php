<?php
/**
 * Plugin Name: Octagono - Crear Usuario con Área
 * Description: API REST para crear un usuario de WordPress junto con su membresía de área.
 * Version: 1.0
 * Author: Cristian
 */

// Evita el acceso directo al archivo
if ( ! defined('ABSPATH') ) {
    exit;
}

/**
 * API REST: Crear usuario + membresía de área
 *
 * Endpoint: POST /wp-json/octagono/v1/create-user-area
 *
 * Body esperado (JSON):
 * {
 *   "email": "correo@dominio.com",
 *   "password": "unaClave123",
 *   "area_id": 5
 * }
 *
 * Flujo:
 * 1. Busca area_id en wp_areas. Si no existe -> error, no hace nada más.
 * 2. Extrae fecha_expiracion de esa área.
 * 3. Crea el usuario de WordPress con el correo y password recibidos.
 * 4. Inserta un registro en wp_user_members:
 *    - area_id  = area_id recibido
 *    - user_id  = id del usuario recién creado
 *    - status   = 'ACTIVO'
 *    - days     = 0
 *    - fecha_final_membresia = fecha_expiracion formateada como dd-mm-yyyy
 * 5. Responde éxito o error.
 */

add_action('rest_api_init', function () {
    register_rest_route('octagono/v1', '/create-user-area', [
        'methods'             => 'POST',
        'callback'            => 'octagono_api_create_user_area',
        'permission_callback' => 'octagono_api_check_token_area', // cambia o reutiliza tu validación de token existente
    ]);
});

/**
 * Token fijo de autenticación para este endpoint.
 * IMPORTANTE: mantenlo en secreto, no lo publiques ni lo subas a repos públicos.
 */
define('OCTAGONO_API_TOKEN', '779f441184653235126cbda0d78e8cf1b5531b556a77af0d61638760c8ffc56e');

/**
 * Validación del token Bearer (token fijo)
 */
function octagono_api_check_token_area( WP_REST_Request $request ) {

    $auth_header = $request->get_header('authorization');

    if ( ! $auth_header || ! str_starts_with($auth_header, 'Bearer ') ) {
        return new WP_Error(
            'unauthorized',
            'Missing Authorization header',
            ['status' => 401]
        );
    }

    $token_received = trim(str_replace('Bearer', '', $auth_header));

    if ( ! hash_equals(OCTAGONO_API_TOKEN, $token_received) ) {
        return new WP_Error(
            'unauthorized',
            'Invalid API token',
            ['status' => 403]
        );
    }

    return true;
}

/**
 * Genera una cadena de letras minúsculas aleatorias (a-z)
 *
 * @param int $length Cantidad de letras a generar
 * @return string
 */
function octagono_generar_letras_random( $length = 5 ) {
    $letras   = 'abcdefghijklmnopqrstuvwxyz';
    $random   = '';
    $max      = strlen($letras) - 1;

    for ( $i = 0; $i < $length; $i++ ) {
        $random .= $letras[ random_int(0, $max) ];
    }

    return $random;
}

/**
 * Callback principal: crea el usuario y su registro de membresía de área
 */
function octagono_api_create_user_area( WP_REST_Request $request ) {

    global $wpdb;

    $data = $request->get_json_params();

    // ----------------------------------
    // Validaciones básicas del payload
    // ----------------------------------
    if ( empty($data['email']) || empty($data['password']) || empty($data['area_id']) ) {
        return new WP_REST_Response([
            'success' => false,
            'message' => 'Faltan datos requeridos: email, password, area_id'
        ], 400);
    }

    $email    = sanitize_email($data['email']);
    $password = (string) $data['password'];
    $area_id  = absint($data['area_id']);

    if ( ! is_email($email) ) {
        return new WP_REST_Response([
            'success' => false,
            'message' => 'El correo electrónico no es válido'
        ], 400);
    }

    // ----------------------------------
    // 1. Buscar el area_id en wp_areas
    // ----------------------------------
    $areas_table = $wpdb->prefix . 'areas';

    $area = $wpdb->get_row(
        $wpdb->prepare(
            "SELECT id, fecha_expiracion FROM {$areas_table} WHERE id = %d",
            $area_id
        )
    );

    if ( ! $area ) {
        return new WP_REST_Response([
            'success' => false,
            'message' => 'El área especificada no existe'
        ], 404);
    }

    // ----------------------------------
    // 2. Extraer fecha_expiracion y formatearla a dd-mm-yyyy
    //    Si no existe o es inválida, se detiene el proceso (no se crea el usuario)
    // ----------------------------------
    if ( empty($area->fecha_expiracion) || $area->fecha_expiracion === '0000-00-00' ) {
        return new WP_REST_Response([
            'success' => false,
            'message' => 'El área no tiene una fecha de expiración configurada'
        ], 422);
    }

    $timestamp = strtotime($area->fecha_expiracion);

    if ( ! $timestamp ) {
        return new WP_REST_Response([
            'success' => false,
            'message' => 'La fecha de expiración del área no es válida'
        ], 422);
    }

    $fecha_final_membresia = date('d-m-Y', $timestamp);

    // ----------------------------------
    // 3. Validar que el correo no exista ya como usuario
    // ----------------------------------
    if ( email_exists($email) ) {
        return new WP_REST_Response([
            'success' => false,
            'message' => 'Ya existe un usuario con ese correo electrónico'
        ], 409);
    }

    // ----------------------------------
    // 4. Crear el usuario de WordPress
    // ----------------------------------

    // Genera el user_nicename a partir de la parte del correo antes de la @,
    // concatenando letras aleatorias al final (ej: "juan" -> "juan-xkqrt")
    $email_local_part = explode('@', $email)[0];
    $nicename_base     = sanitize_title($email_local_part);
    $random_letters    = octagono_generar_letras_random(5);
    $user_nicename     = $nicename_base . '-' . $random_letters;

    $user_id = wp_insert_user([
        'user_login'    => $email,
        'user_email'    => $email,
        'user_pass'     => $password,
        'user_nicename' => $user_nicename,
        'role'          => 'customer',
    ]);

    if ( is_wp_error($user_id) ) {
        return new WP_REST_Response([
            'success' => false,
            'message' => 'Error al crear el usuario: ' . $user_id->get_error_message()
        ], 500);
    }

    // ----------------------------------
    // 5. Insertar el registro en wp_user_members
    // ----------------------------------
    $members_table = $wpdb->prefix . 'user_members';

    $inserted = $wpdb->insert(
        $members_table,
        [
            'area_id'               => $area_id,
            'user_id'               => $user_id,
            'status'                => 'ACTIVO',
            'days'                  => 0,
            'fecha_final_membresia' => $fecha_final_membresia,
        ],
        [
            '%d', // area_id
            '%d', // user_id
            '%s', // status
            '%d', // days
            '%s', // fecha_final_membresia
        ]
    );

    if ( $inserted === false ) {
        // El usuario ya se creó, pero falló el registro de membresía.
        // Se informa el error indicando que el usuario sí quedó creado.
        return new WP_REST_Response([
            'success' => false,
            'message' => 'El usuario se creó, pero ocurrió un error al registrar la membresía del área',
            'user_id' => $user_id,
        ], 500);
    }

    // ----------------------------------
    // 6. Respuesta de éxito
    // ----------------------------------
    return new WP_REST_Response([
        'success'                => true,
        'message'                => 'Usuario y membresía creados correctamente',
        'user_id'                => $user_id,
        'user_nicename'          => $user_nicename,
        'area_id'                => $area_id,
        'status'                 => 'ACTIVO',
        'fecha_final_membresia'  => $fecha_final_membresia,
    ], 201);
}
